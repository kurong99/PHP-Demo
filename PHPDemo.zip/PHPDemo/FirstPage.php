<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Page</title>
</head>
<body>
    <h1>FirstPage</h1>
    <?php
    echo "Hello World";
    ?>
    <?php
    //phpinfo();输出php版本信息
    $Int = 10;//定义int型变量 不分大小写
    echo "$Int";//输出变量
    //单双引号的使用区别
    $int = 11;
    echo "双引号输出$int";//双引号输出11
    echo '单引号输出$int';//单引号输出$int
    ?>
    <p>this is my house</p>
    <?php echo "some text" ?>
    <p>this is my house</p>
    <?php
        $name = $_POST["userName"];
        $pwd = $_POST["passWord"];
        echo "欢迎你，$name!!!";
    ?>
</body>
</html>